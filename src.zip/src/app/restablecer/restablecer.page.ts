import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-restablecer',
  templateUrl: './restablecer.page.html',
  styleUrls: ['./restablecer.page.scss'],
})
export class RestablecerPage {

  constructor(private router: Router) {}

  // Método para navegar de regreso a la página de inicio
  goBack() {
    this.router.navigate(['/home']);
  }

  // Método para manejar el restablecimiento de contraseña
  restablecer() {
    // Aquí puedes agregar la lógica para restablecer la contraseña
    console.log('Restablecimiento de contraseña solicitado');
  }
}
