// home.page.ts
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage {
  nombre: string = '';

  constructor(private router: Router) {}

  // Método para enviar el nombre a la página de inicio de sesión
  login() {
    this.router.navigate(['/login'], { queryParams: { nombre: this.nombre } });
  }
}