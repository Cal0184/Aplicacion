import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ParamMap } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  nombre: string = '';

  constructor(private router: Router, private activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    // Obtén el parámetro 'nombre' de la URL
    this.activatedRoute.queryParams.subscribe(params => {
      this.nombre = params['nombre'] || '';
    });
  }

  goBack() {
    this.router.navigate(['/home']);
  }

  login() {
    console.log('Iniciar sesión con el nombre:', this.nombre);
    // Aquí puedes agregar lógica para iniciar sesión
  }
}



